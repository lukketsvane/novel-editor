import { NextResponse } from 'next/server'
import { Octokit } from '@octokit/rest'

if (!process.env.GITHUB_PAT) {
  console.error('GITHUB_PAT is not set in the environment variables')
  process.exit(1)
}

const octokit = new Octokit({ auth: process.env.GITHUB_PAT })
const owner = 'lukketsvane'
const repo = 'personal-web'

async function fetchDirectoryContents(path: string): Promise<Array<{ name: string; path: string; type: string }>> {
  try {
    const { data } = await octokit.repos.getContent({ owner, repo, path })
    if (!Array.isArray(data)) throw new Error('Expected directory contents, received file')
    
    return await Promise.all(data.map(async item => ({
      name: item.name,
      path: item.path,
      type: item.type,
      ...(item.type === 'dir' ? { children: await fetchDirectoryContents(item.path) } : {})
    })))
  } catch (error) {
    console.error(`Error fetching contents for path ${path}:`, error)
    return []
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const path = searchParams.get('path')
  
  if (path) {
    try {
      const { data } = await octokit.repos.getContent({ owner, repo, path })
      if ('content' in data) {
        return NextResponse.json({ content: Buffer.from(data.content, 'base64').toString('utf-8') })
      }
      throw new Error('Not a file')
    } catch (error) {
      console.error('Error fetching file content:', error)
      return NextResponse.json({ error: 'Failed to fetch file content' }, { status: 500 })
    }
  } else {
    try {
      const files = await fetchDirectoryContents('')
      return NextResponse.json(files)
    } catch (error) {
      console.error('Error fetching repository contents:', error)
      return NextResponse.json({ error: 'Failed to fetch repository contents' }, { status: 500 })
    }
  }
}

export async function POST(request: Request) {
  const formData = await request.formData()
  const file = formData.get('file') as File | null

  if (file) {
    const buffer = await file.arrayBuffer()
    const content = Buffer.from(buffer).toString('base64')
    const path = `images/${Date.now()}-${file.name}`
    return handleFileOperation('createOrUpdateFileContents', { path, message: `Upload image ${file.name}`, content })
  } else {
    const { path, content } = await request.json() as { path: string; content: string }
    if (!path || !content) {
      return NextResponse.json({ error: 'Path and content are required' }, { status: 400 })
    }
    const { data: currentFile } = await octokit.repos.getContent({ owner, repo, path }).catch(() => ({ data: null }))
    return handleFileOperation('createOrUpdateFileContents', {
      path,
      message: `Update ${path}`,
      content: Buffer.from(content).toString('base64'),
      sha: currentFile && !Array.isArray(currentFile) ? currentFile.sha : undefined,
    })
  }
}

export async function PUT(request: Request) {
  const { oldPath, newName } = await request.json() as { oldPath: string; newName: string }
  const { data: content } = await octokit.repos.getContent({ owner, repo, path: oldPath })

  if (Array.isArray(content)) {
    for (const item of content) {
      const newPath = item.path.replace(oldPath, newName)
      await handleFileOperation('createOrUpdateFileContents', {
        path: newPath,
        message: `Move ${item.path} to ${newPath}`,
        content: item.content || '',
        sha: item.sha,
      })
      await handleFileOperation('deleteFile', {
        path: item.path,
        message: `Delete ${item.path} after move`,
        sha: item.sha,
      })
    }
  } else {
    const newPath = oldPath.split('/').slice(0, -1).concat(newName).join('/')
    await handleFileOperation('createOrUpdateFileContents', {
      path: newPath,
      message: `Move ${oldPath} to ${newPath}`,
      content: content.content,
      sha: content.sha,
    })
    await handleFileOperation('deleteFile', {
      path: oldPath,
      message: `Delete ${oldPath} after move`,
      sha: content.sha,
    })
  }

  return NextResponse.json({ success: true })
}

export async function DELETE(request: Request) {
  const { path } = await request.json() as { path: string }
  const { data: contents } = await octokit.repos.getContent({ owner, repo, path })

  if (Array.isArray(contents)) {
    for (const item of contents) {
      await handleFileOperation('deleteFile', {
        path: item.path,
        message: `Delete ${item.path}`,
        sha: item.sha,
      })
    }
  } else {
    await handleFileOperation('deleteFile', {
      path,
      message: `Delete ${path}`,
      sha: contents.sha,
    })
  }

  return NextResponse.json({ success: true })
}

async function handleFileOperation(operation: 'createOrUpdateFileContents' | 'deleteFile', params: Record<string, unknown>) {
  try {
    const response = await octokit.repos[operation]({ owner, repo, ...params })
    return NextResponse.json({ success: true, data: response.data })
  } catch (error) {
    console.error(`Error in ${operation}:`, error)
    return NextResponse.json({
      error: `Failed to ${operation.split('OrUpdate')[0].toLowerCase()}`,
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}